<?php
echo rand(0, 100);