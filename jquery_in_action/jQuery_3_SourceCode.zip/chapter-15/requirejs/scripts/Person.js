define({
   name: 'John Doe'
});